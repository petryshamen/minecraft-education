HUMAN JOURNEY v0.1 — VISUAL SKELETON

Target: Minecraft Java 1.21.8 / data pack format 81.

Install:
1. Put Human_Journey_v0_1.zip into <active world>/datapacks/
2. Run /reload
3. Run /datapack list
4. Press L and look for ERA 0 — The First Camp

Debug:
 /function human_journey:debug/grant_all
 /function human_journey:debug/revoke_all

This build tests only the tab and tree layout.
Automatic triggers, shared team progress, Tough As Nails items,
Jengo, coordinates and Era 1 unlocks come in the next build.
