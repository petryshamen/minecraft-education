clear @s minecraft:potion 1
give @s toughasnails:dirty_water_bottle 1
execute if items entity @s inventory.* minecraft:potion run function human_journey:water/convert_one
