HUMAN JOURNEY v0.3.2 — LOCK SYSTEM FIX
Minecraft Java 1.21.8 / Forge

Still test this on the random test world first.

WHAT THIS FIXES

1) WATER FROM THE WORLD
The previous component-specific Water Bottle detection did not match your bottle.
v0.3.2 deliberately uses a simpler early-era rule:

While LATE_GAME / brewing is locked, ANY vanilla minecraft:potion in a STUDENT'S
inventory is treated as untreated source water and converted to:
  toughasnails:dirty_water_bottle

This is safe for Era 0 because students cannot brew legitimate potions yet.

Dirty water now has THREE cleaning options:
A) Put Dirty Water Bottle on a campfire -> Purified Water Bottle
B) Smelt Dirty Water Bottle in a furnace -> Purified Water Bottle
C) Craft Dirty Water Bottle + Charcoal -> Purified Water Bottle

No Tough As Nails or GlitchCore JAR is modified.

2) LOCKS ARE AUTOMATIC
Technology enforcement is scheduled every second.
You should NOT need to manually run lock_* commands during normal play.

3) FURNACE METAL BYPASS
doLimitedCrafting blocks crafting recipes, but furnace processing is not a reliable
technology gate.

So v0.3.2 also enforces metallurgy at the PLAYER level:
- locked Iron Ingot -> immediately returned as Raw Iron
- locked Copper Ingot -> immediately returned as Raw Copper
- locked Gold Ingot -> immediately returned as Raw Gold

Students may discover and collect ore. They simply do not yet know how to turn it
into usable worked metal. When the technology is unlocked, this conversion stops.

This also blocks Tough As Nails' copper Water Purifier in practice because students
cannot keep copper ingots before Copper Working.

4) MOD PROGRESSION
Uploaded JARs were inspected and integrated.

Only Hammers and Excavators:
ALL 20 hammers/excavators are locked under MASS_MINING, including wooden and stone.
Reason: they massively increase extraction speed and should represent a later
productivity technology.

PackedUp:
Backpack recipe advancements are suppressed and backpack recipes are locked under
BACKPACKS. Bundle remains the Era 0 carrying milestone.

Tough As Nails:
Allowed in Era 0:
- leaf clothing
- wool clothing
- leather canteen
- rain collector
- basic survival food/drink recipes

Locked with COPPER:
- Copper Canteen
- Water Purifier

Locked with IRON:
- Iron Canteen

Locked with GOLD:
- Gold Canteen

Locked with DIAMOND:
- Diamond Canteen

Locked with REDSTONE:
- Thermometer
- Temperature Gauge
- Thermoregulator

Locked with LATE_GAME:
- Netherite canteen upgrades

5) WHAT "ADVANCED" USED TO MEAN
v0.3.1's vague ADVANCED group contained:
- Brewing Stand
- Eye of Ender
- Ender Chest
- Beacon
- late Netherite Tough As Nails items

It has been renamed LATE_GAME in v0.3.2.

TECHNOLOGY DEBUG

Unlock:
  /function human_journey:debug/unlock_agriculture
  /function human_journey:debug/unlock_copper
  /function human_journey:debug/unlock_iron
  /function human_journey:debug/unlock_gold
  /function human_journey:debug/unlock_diamond
  /function human_journey:debug/unlock_redstone
  /function human_journey:debug/unlock_mass_mining
  /function human_journey:debug/unlock_backpacks
  /function human_journey:debug/unlock_late_game

Re-lock uses the same names with lock_ instead of unlock_.

TEST THESE NOW

WATER
1. /function human_journey:setup/student
2. Fill an ordinary glass bottle from the sea/river.
3. It should become Dirty Water Bottle almost immediately.
4. Put Dirty Water Bottle on a campfire: it should cook to purified water.
5. Also test Dirty Water + Charcoal.

AUTOMATIC LOCK
Do NOT run any manual lock command.
After /reload and STUDENT setup:
- wooden hoe should be unavailable
- iron/diamond/redstone crafts should be unavailable
- Tough As Nails Water Purifier should be unavailable
- PackedUp backpack should be unavailable
- wooden/stone hammer should be unavailable

METAL
Give/smelt one Raw Iron.
When you take the Iron Ingot into inventory, it should immediately turn back into Raw Iron.
Repeat with Copper and Gold.

Then:
  /function human_journey:debug/unlock_copper
Smelt raw copper again.
The Copper Ingot should now remain usable.

RECIPE BOOK
v0.3.2 also suppresses recipe-unlock advancements for the two uploaded utility mods
and for targeted locked vanilla recipes. This should reduce locked recipes appearing
in the recipe book.

Some modded recipe viewers may still DISPLAY recipes even when Minecraft itself
forbids crafting them. If that still happens, send a screenshot of exactly which UI
is showing them; that is a separate client-side display problem from the server lock.

TEACHER
Teacher setup now grants the teacher all recipes:
  /function human_journey:setup/teacher
Teacher actions still do not advance Human Journey.

CURRENT ERA 0 POLICY
Locked:
Agriculture / Copper / Iron / Gold / Diamond / Redstone / Mass Mining / Backpacks / Late Game.

Allowed:
wood and stone basic tools, bow, fishing rod, boat, furnace, campfire,
leather/leaf/wool clothing, bed, bundle, normal building blocks,
primitive clean-water methods.

Important: Era and technology remain separate.
WE CAN STAY unlocks AGRICULTURE only.
Future story/technology advancements will unlock Copper, Iron, Backpacks, etc.
