HUMAN JOURNEY v0.2 — TEST BUILD
Minecraft Java 1.21.8 / Forge

IMPORTANT
This build is still for a TEST WORLD. Do not replace the live teaching-server pack yet.
It now contains real triggers and one custom Tough As Nails recipe, so test each item first.

WHAT CHANGED
- Moss block background.
- Shared civilization progress.
- Teacher/student roles.
- Automatic Era 0 triggers for vanilla actions.
- Real equipped-clothing check.
- Mogadishu 500-block travel check.
- Approximate Europe coordinate zone.
- Manual events for first trade and Jengo.
- Primitive water boiling recipe:
    toughasnails:dirty_water_bottle
        -> campfire cooking ->
    toughasnails:purified_water_bottle
  This DOES NOT modify the Tough As Nails .jar.
  It only adds another server data-pack recipe.

INSTALL
1. Remove Human_Journey_v0_1.zip from the TEST world's datapacks folder.
2. Put Human_Journey_v0_2.zip there.
3. /reload
4. /datapack list

ROLE SETUP
While testing yourself:
  /function human_journey:setup/student

When you want to test teacher mode:
  /function human_journey:setup/teacher

On the real server later:
- each pupil runs/is assigned setup/student once
- teacher runs/is assigned setup/teacher once
Both roles see the same shared visible advancement tree.
Only STUDENT actions can move shared civilization progress.

ERA 0 ORDER

SURVIVAL
The First Flame
  -> Ready to Eat
  -> Water for Life
  -> A Reliable Source
  -> Rest at Last

TOOLS & CLOTHING
First Wood
  -> A Place to Work
  -> First Tool
  -> Stone Age
  -> A Better Edge
  -> Dressed for the Wild
  -> Carry What You Can

JOURNEY
Beyond the Camp
  -> A Stranger from Afar
  -> The Land Beyond
  -> A New Continent

AUTOMATIC
- First Flame: craft minecraft:campfire
- Ready to Eat: obtain cooked fish/meat from the Human Journey food tag
- Water for Life: obtain toughasnails:purified_water_bottle
- Rest at Last: sleep in a bed
- First Wood: obtain any #minecraft:logs
- A Place to Work: craft crafting table
- First Tool: craft wooden pickaxe
- Stone Age: obtain cobblestone/cobbled deepslate
- A Better Edge: craft stone axe
- Dressed for the Wild: wear one leather / Tough As Nails wool / Tough As Nails leaf armor piece
- Carry What You Can: craft bundle
- Beyond the Camp: 500+ blocks away from Mogadishu (3092,66,-192)
- A New Continent: enter approximate Europe zone AFTER The Land Beyond

MANUAL STORY / NPC EVENTS
Run these AS THE STUDENT who triggered the event:
  /function human_journey:event/first_trade
  /function human_journey:event/meet_jengo
  /function human_journey:event/land_beyond

These are intended to be attached to Easy NPC actions later.

EUROPE TEST ZONE
Approximate v0.2 rectangle:
  X: -1700 .. 4100
  Z: -6500 .. -2350
It includes Kyiv (2127,-3421) and excludes Cairo (2133,-2047).
More map coordinates can refine this later.

WATER TEST
1. Get a dirty bottle:
   /give @s toughasnails:dirty_water_bottle
2. Put it on a lit campfire.
3. After ~10 seconds it should pop off as:
   toughasnails:purified_water_bottle
4. If you have already completed Ready to Eat, Water for Life should unlock.

SEQUENCE TEST
If you obtain/craft something too early, it should NOT permanently skip the chain.
For event-based hidden advancements, the internal trigger is revoked when its prerequisite
has not been completed, allowing the action to count later.

TEST RESET — TEST WORLD ONLY
  /function human_journey:debug/reset_test_world

WARNING: the reset function revokes advancements and is not for the live class world.

WHEN IS IT SAFE FOR THE REAL SERVER?
v0.2 = test world only.
Move to a copy/backup of the real Earth server after:
- /reload shows no data-pack errors
- each automatic advancement has been tested once
- the water recipe works
- teacher mode cannot move progress
- manual NPC event functions work
- Europe trigger behaves correctly

After those pass, make v0.3 as the release candidate.
Only v0.3 (after a backup) should be tested on the real Earth-server copy.
