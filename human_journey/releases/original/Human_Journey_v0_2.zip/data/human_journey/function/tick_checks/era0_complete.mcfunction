scoreboard players set #we_can_stay hj_civ 1
scoreboard players set #era1 hj_civ 1
tellraw @a[tag=hj_participant] {"text":"ERA 0 COMPLETE — WE CAN STAY","color":"gold","bold":true}
function human_journey:sync
