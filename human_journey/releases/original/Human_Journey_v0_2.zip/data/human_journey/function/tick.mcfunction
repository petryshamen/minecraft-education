# Keep visible shared progress synchronized.
function human_journey:sync

# Journey: 500+ blocks from Mogadishu (3092, 66, -192).
execute as @a[tag=hj_student,x=3092,y=66,z=-192,distance=500..] if score #beyond_camp hj_civ matches 0 run function human_journey:tick_checks/beyond_camp
execute as @a[tag=hj_student,x=3092,y=66,z=-192,distance=500..] unless score #beyond_camp hj_civ matches 0.. run function human_journey:tick_checks/beyond_camp

# Clothing: any allowed leather / wool / leaf piece actually equipped.
execute as @a[tag=hj_student] if score #better_edge hj_civ matches 1 unless score #dressed_for_wild hj_civ matches 1 if items entity @s armor.head #human_journey:early_clothing run function human_journey:tick_checks/dressed
execute as @a[tag=hj_student] if score #better_edge hj_civ matches 1 unless score #dressed_for_wild hj_civ matches 1 if items entity @s armor.chest #human_journey:early_clothing run function human_journey:tick_checks/dressed
execute as @a[tag=hj_student] if score #better_edge hj_civ matches 1 unless score #dressed_for_wild hj_civ matches 1 if items entity @s armor.legs #human_journey:early_clothing run function human_journey:tick_checks/dressed
execute as @a[tag=hj_student] if score #better_edge hj_civ matches 1 unless score #dressed_for_wild hj_civ matches 1 if items entity @s armor.feet #human_journey:early_clothing run function human_journey:tick_checks/dressed

# Europe approximation from the supplied Earth-map coordinates.
# X ~= longitude, Z becomes more negative toward the north.
# Current v0.2 test zone: X -1700..4100, Y -64..386, Z -6500..-2350.
execute as @a[tag=hj_student,x=-1700,y=-64,z=-6500,dx=5800,dy=450,dz=4150] if score #land_beyond hj_civ matches 1 unless score #new_continent hj_civ matches 1 run function human_journey:tick_checks/europe

# Era 0 capstone.
execute if score #rest_at_last hj_civ matches 1 if score #carry_what_you_can hj_civ matches 1 if score #new_continent hj_civ matches 1 unless score #we_can_stay hj_civ matches 1 run function human_journey:tick_checks/era0_complete
