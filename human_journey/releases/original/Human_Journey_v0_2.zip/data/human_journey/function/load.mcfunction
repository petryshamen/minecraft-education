scoreboard objectives add hj_civ dummy
tellraw @a[tag=hj_participant] {"text":"[Human Journey] v0.2 loaded.","color":"dark_green"}
function human_journey:sync
