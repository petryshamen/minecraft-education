HUMAN JOURNEY v0.3.1 — TECHNOLOGY LOCK TEST
Minecraft Java 1.21.8 / Forge

THIS IS STILL A TEST-WORLD BUILD.

NEW: REAL RECIPE LOCKS
The pack now enables:
  /gamerule doLimitedCrafting true

While a technology is locked, its recipes are repeatedly removed from STUDENTS'
recipe books. With limited crafting enabled, students cannot craft those recipes
even by manually placing the ingredients in the crafting grid.

Teacher creative-mode inventory is unaffected, but a teacher in normal survival
will also be subject to the global limited-crafting rule for recipes they do not know.
For testing a technology, temporarily use STUDENT mode or the debug unlock functions.

ERA 0 LOCKS

1) AGRICULTURE
- wooden hoe
- stone hoe
- bread
- composter
- hay bale
- hay bale -> wheat conversion

This prevents the group from jumping straight into farming.
When ERA 0 is completed, ERA 1 — The First Fields automatically unlocks AGRICULTURE.

2) IRON WORKING
- smelting and blasting iron ore/raw iron
- iron tools and armor
- bucket, shears, flint and steel, shield
- cauldron, anvil, hopper
- minecart, iron bars/doors/trapdoor
- chain, lantern
- blast furnace, smithing table, stonecutter
- crossbow, compass
- iron block/nugget conversions

3) COPPER WORKING
- smelting and blasting copper ore/raw copper
- copper block
- lightning rod
- spyglass
- brush

4) GOLD WORKING
- smelting/blasting gold
- golden tools/armor
- golden apple/carrot
- clock, powered rail
- gold block/nugget conversions

5) DIAMOND TECHNOLOGY
- diamond tools/armor
- diamond block
- enchanting table
- jukebox

6) REDSTONE / MECHANICAL TECHNOLOGY
- redstone torch
- repeater/comparator
- piston/sticky piston
- observer
- dispenser/dropper
- note block
- daylight detector/target
- detector/activator rail
- TNT

7) OTHER ADVANCED
- brewing stand
- Eye of Ender
- Ender Chest
- beacon

NOT LOCKED ON PURPOSE IN THIS TEST
- furnace: treated as a generic oven/hearth
- campfire
- smoker
- wooden/stone non-hoe tools
- bow
- boat
- leather / leaf / wool clothing
- bed
- bundle
- glass bottle (needed by the current Tough As Nails water loop)

WATER
Both primitive cleaning methods are now available:
A) Craft:
   Dirty Water Bottle + Charcoal -> Purified Water Bottle
B) "Boil":
   Put Dirty Water Bottle in a normal furnace -> Purified Water Bottle

The furnace route is used because a drinkable bottle cannot be placed on a campfire
with right-click: Minecraft drinks it instead.

TEST COMMANDS

Assign yourself:
  /function human_journey:setup/student

Check limited crafting:
  /gamerule doLimitedCrafting

Try these while Era 0 is active:
- craft a stone axe -> should work when its advancement sequence allows normal recipe unlock
- craft a wooden hoe -> should FAIL
- smelt raw iron -> should FAIL
- craft shears from creative-given iron ingots -> should FAIL
- smelt raw copper -> should FAIL
- craft a diamond pickaxe from creative-given diamonds -> should FAIL

TECHNOLOGY DEBUG UNLOCKS:
  /function human_journey:debug/unlock_agriculture
  /function human_journey:debug/unlock_iron
  /function human_journey:debug/unlock_copper
  /function human_journey:debug/unlock_gold
  /function human_journey:debug/unlock_diamond
  /function human_journey:debug/unlock_redstone
  /function human_journey:debug/unlock_advanced

Corresponding re-locks:
  /function human_journey:debug/lock_agriculture
  /function human_journey:debug/lock_iron
  /function human_journey:debug/lock_copper
  /function human_journey:debug/lock_gold
  /function human_journey:debug/lock_diamond
  /function human_journey:debug/lock_redstone
  /function human_journey:debug/lock_advanced

IMPORTANT ARCHITECTURE
Era and Technology are separate.
Completing an Era does NOT automatically unlock all later materials.
Future technology/story advancements will call these same unlock functions.

At the moment only AGRICULTURE is automatically opened by completing ERA 0,
because ERA 1 is currently "The First Fields".
Copper, iron, gold, diamond, redstone, etc. stay locked.

WHY THIS IS A TEST
Vanilla and mods can add unusual or special recipes. v0.3.1 locks the major
progression-breaking recipes, but we should try to bypass the system before using
it in class. If you find a recipe that still lets students jump ahead, note the item
and it can be added to the proper technology group.
