# Keep visible shared progress synchronized.
function human_journey:sync

# ERA 0 WATER:
# During Era 0, ordinary vanilla Water Bottles represent untreated water.
# Convert them automatically to Tough As Nails dirty water for STUDENTS.
execute as @a[tag=hj_student] unless score #era1 hj_civ matches 1 if items entity @s inventory.* minecraft:potion[minecraft:potion_contents~{potion:"minecraft:water"}] run function human_journey:water/convert_one

# Journey: 500+ blocks from Mogadishu (3092, 66, -192).
execute as @a[tag=hj_student,x=3092,y=66,z=-192,distance=500..] unless score #beyond_camp hj_civ matches 1 run function human_journey:tick_checks/beyond_camp

# Clothing: any allowed leather / wool / leaf piece actually equipped.
execute as @a[tag=hj_student] if score #better_edge hj_civ matches 1 unless score #dressed_for_wild hj_civ matches 1 if items entity @s armor.head #human_journey:early_clothing run function human_journey:tick_checks/dressed
execute as @a[tag=hj_student] if score #better_edge hj_civ matches 1 unless score #dressed_for_wild hj_civ matches 1 if items entity @s armor.chest #human_journey:early_clothing run function human_journey:tick_checks/dressed
execute as @a[tag=hj_student] if score #better_edge hj_civ matches 1 unless score #dressed_for_wild hj_civ matches 1 if items entity @s armor.legs #human_journey:early_clothing run function human_journey:tick_checks/dressed
execute as @a[tag=hj_student] if score #better_edge hj_civ matches 1 unless score #dressed_for_wild hj_civ matches 1 if items entity @s armor.feet #human_journey:early_clothing run function human_journey:tick_checks/dressed

# Europe approximation.
# Derived from supplied Earth-map reference points:
# Mogadishu (3092,-192), Cairo (2133,-2047), Kyiv (2127,-3421).
# Current region is intentionally broad; A New Continent can only trigger
# after Jengo's The Land Beyond event.
execute as @a[tag=hj_student,x=-1700,y=-64,z=-6500,dx=5800,dy=450,dz=4150] if score #land_beyond hj_civ matches 1 unless score #new_continent hj_civ matches 1 run function human_journey:tick_checks/europe

# Era 0 capstone: ALL THREE branch endpoints are required.
execute if score #rest_at_last hj_civ matches 1 if score #carry_what_you_can hj_civ matches 1 if score #new_continent hj_civ matches 1 unless score #we_can_stay hj_civ matches 1 run function human_journey:tick_checks/era0_complete

# TECHNOLOGY LOCKS
# doLimitedCrafting=true means forgotten recipes cannot be used manually.
execute unless score #tech_agriculture hj_civ matches 1 run function human_journey:tech/lock/agriculture
execute unless score #tech_iron hj_civ matches 1 run function human_journey:tech/lock/iron
execute unless score #tech_copper hj_civ matches 1 run function human_journey:tech/lock/copper
execute unless score #tech_gold hj_civ matches 1 run function human_journey:tech/lock/gold
execute unless score #tech_diamond hj_civ matches 1 run function human_journey:tech/lock/diamond
execute unless score #tech_redstone hj_civ matches 1 run function human_journey:tech/lock/redstone
execute unless score #tech_advanced hj_civ matches 1 run function human_journey:tech/lock/advanced
