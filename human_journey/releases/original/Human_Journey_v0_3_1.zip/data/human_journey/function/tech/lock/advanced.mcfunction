recipe take @a[tag=hj_student] minecraft:brewing_stand
recipe take @a[tag=hj_student] minecraft:ender_eye
recipe take @a[tag=hj_student] minecraft:ender_chest
recipe take @a[tag=hj_student] minecraft:beacon
