recipe give @a[tag=hj_student] minecraft:brewing_stand
recipe give @a[tag=hj_student] minecraft:ender_eye
recipe give @a[tag=hj_student] minecraft:ender_chest
recipe give @a[tag=hj_student] minecraft:beacon
