# Convert one vanilla Water Bottle into Tough As Nails dirty water.
clear @s minecraft:potion[minecraft:potion_contents~{potion:"minecraft:water"}] 1
give @s toughasnails:dirty_water_bottle 1
