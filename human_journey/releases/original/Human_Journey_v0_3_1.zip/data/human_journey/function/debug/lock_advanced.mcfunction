scoreboard players set #tech_advanced hj_civ 0
function human_journey:tech/lock/advanced
tellraw @s {"text":"[TEST] ADVANCED technology locked.","color":"yellow"}
