scoreboard players set #tech_advanced hj_civ 1
function human_journey:tech/give/advanced
tellraw @s {"text":"[TEST] ADVANCED technology unlocked.","color":"green"}
