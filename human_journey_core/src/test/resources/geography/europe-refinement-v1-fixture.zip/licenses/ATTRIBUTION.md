Natural Earth physical data: public domain.
GMBA Mountain Inventory v2: Snethlage et al., CC BY 4.0; see SOURCES.md and the dataset DOI.
GSHHG adaptations: original authors and LGPL/GPL notices retained in this directory; adapted masks and authoring code are supplied.
Production HJ metadata remains existing project content; no ownership or licence is changed by this review.
